import torch
import torch.nn as nn


# define the CNN architecture
class MyModel(nn.Module):
    def __init__(self, num_classes: int = 1000, dropout: float = 0.7) -> None:

        super().__init__()
        
        # helper for two-conv blocks with BatchNorm + ReLU
        def conv_block(in_ch: int, out_ch: int) -> nn.Sequential:
            return nn.Sequential(
                nn.Conv2d(in_ch, out_ch, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(out_ch),
                nn.ReLU(inplace=True),
                nn.Conv2d(out_ch, out_ch, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(out_ch),
                nn.ReLU(inplace=True),
            )

        # YOUR CODE HERE
        # Define a CNN architecture. Remember to use the variable num_classes
        # to size appropriately the output of your classifier, and if you use
        # the Dropout layer, use the variable "dropout" to indicate how much
        # to use (like nn.Dropout(p=dropout))
        
        # Feature extractor: five stages of conv_block + pooling
        self.features = nn.Sequential(
            conv_block(3,   32), nn.MaxPool2d(2),  # 224 → 112
            conv_block(32,  64), nn.MaxPool2d(2),  # 112 →  56
            conv_block(64, 128), nn.MaxPool2d(2),  #  56 →  28
            conv_block(128,256), nn.MaxPool2d(2),  #  28 →  14
            conv_block(256,512), nn.MaxPool2d(2),  #  14 →   7
        )
        
        # Pool to 1×1 spatial and classify
        self.avgpool   = nn.AdaptiveAvgPool2d((1, 1))
        self.dropout   = nn.Dropout(p=dropout)
        self.classifier = nn.Linear(512, num_classes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # YOUR CODE HERE: process the input tensor through the
        # feature extractor, the pooling and the final linear
        # layers (if appropriate for the architecture chosen)
        # 1) feature maps
        x = self.features(x)          # (B, 512, 7, 7)
        # 2) spatial squeeze
        x = self.avgpool(x)           # (B, 512, 1, 1)
        # 3) flatten & dropout
        x = torch.flatten(x, 1)       # (B, 512)
        x = self.dropout(x)
        # 4) final logits
        return self.classifier(x)     # (B, num_classes)


######################################################################################
#                                     TESTS
######################################################################################
import pytest


@pytest.fixture(scope="session")
def data_loaders():
    from .data import get_data_loaders

    return get_data_loaders(batch_size=2)


def test_model_construction(data_loaders):

    model = MyModel(num_classes=23, dropout=0.3)

    dataiter = iter(data_loaders["train"])
    images, labels = dataiter.next()

    out = model(images)

    assert isinstance(
        out, torch.Tensor
    ), "The output of the .forward method should be a Tensor of size ([batch_size], [n_classes])"

    assert out.shape == torch.Size(
        [2, 23]
    ), f"Expected an output tensor of size (2, 23), got {out.shape}"
