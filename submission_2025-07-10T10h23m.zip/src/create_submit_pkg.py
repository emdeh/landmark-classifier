import datetime
import glob
import subprocess
import zipfile


def create_submit_pkg():
    # Source files
    src_files = glob.glob("src/*.py")

    # Notebooks
    notebooks = glob.glob("*.ipynb")

    # Generate HTML from the notebooks
    for nb in notebooks:
        cmd_line = f"jupyter nbconvert --to html {nb}"
        print(f"executing: {cmd_line}")
        subprocess.check_call(cmd_line, shell=True)

    html_files = glob.glob("*.htm*")

    # Timestamped output filename
    now = datetime.datetime.today() \
        .isoformat(timespec="minutes") \
        .replace(":", "h") + "m"
    outfile = f"submission_{now}.zip"
    print(f"Adding files to {outfile}")

    # Create ZIP archive
    with zipfile.ZipFile(outfile, mode="w", compression=zipfile.ZIP_DEFLATED) as zf:
        for name in src_files + notebooks + html_files:
            print(f"  adding {name}")
            zf.write(name)

    print("")
    msg = f"Done. Please submit the file {outfile}"
    print("-" * len(msg))
    print(msg)
    print("-" * len(msg))


if __name__ == "__main__":
    create_submit_pkg()
